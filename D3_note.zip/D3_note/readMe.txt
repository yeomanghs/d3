#start server
python -m http.server